package br.com.portoseguro.crypter.crypter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrypterApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrypterApplication.class, args);
	}
}
